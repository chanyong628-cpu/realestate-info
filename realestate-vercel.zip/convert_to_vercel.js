// convert_to_vercel.js
import fs from "fs";
import JSZip from "jszip";
import { parseStringPromise } from "xml2js";
import path from "path";

async function convertToVercel() {
  const basePath = "C:/realestate/realestate.zip";
  const data = fs.readFileSync(basePath);
  const JSZipLib = new JSZip();
  const zip = await JSZipLib.loadAsync(data);
  const newZip = new JSZip();

  for (const filename of Object.keys(zip.files)) {
    const file = zip.files[filename];
    if (!file.dir) {
      const content = await file.async("string");
      newZip.file(filename, content);
    }
  }

  newZip.file("api/building.js", `
    import fetch from "node-fetch";
    import { parseStringPromise } from "xml2js";

    export default async function handler(req, res) {
      const { addr } = req.query;
      const SEOUL_API_KEY = process.env.SEOUL_API_KEY;
      const MOLIT_API_KEY = process.env.MOLIT_API_KEY;
      try {
        const addrUrl = \`https://openapi.seoul.go.kr:8088/\${SEOUL_API_KEY}/json/GeoInfoAddress/1/5/\${encodeURIComponent(addr)}\`;
        const addrRes = await fetch(addrUrl);
        const addrData = await addrRes.json();
        const addrInfo = addrData.GeoInfoAddress?.row?.[0];
        if (!addrInfo) return res.status(404).json({ error: "주소를 찾을 수 없습니다." });

        const sigCd = addrInfo.SIG_CD || "11710";
        const bjdongCd = addrInfo.BJDONG_CD || "10400";
        const bun = addrInfo.BUN?.padStart(4, "0") || "0000";
        const ji = addrInfo.JI || "";

        const bldUrl = \`https://apis.data.go.kr/1613000/BldRgstService_v2/getBrTitleInfo?sigunguCd=\${sigCd}&bjdongCd=\${bjdongCd}&bun=\${bun}&ji=\${ji}&ServiceKey=\${MOLIT_API_KEY}&_type=xml\`;
        const bldRes = await fetch(bldUrl);
        const xmlText = await bldRes.text();
        const xmlData = await parseStringPromise(xmlText);
        const item = xmlData?.response?.body?.[0]?.items?.[0]?.item?.[0];

        if (!item) return res.status(404).json({ error: "건축물 정보를 찾을 수 없습니다." });

        res.status(200).json({
          address: \`\${addrInfo.SIGUN_NM || ""} \${addrInfo.BJDONG_NM || ""} \${addrInfo.BUN || ""}\`,
          usageApproval: item.useAprDay?.[0] || "?",
          structure: item.strctCdNm?.[0] || "?",
          usage: item.mainPurpsCdNm?.[0] || "?",
          floors: item.grndFlrCnt?.[0] || "?",
          parking: item.totPkngCnt?.[0] || "?"
        });
      } catch (error) {
        res.status(500).json({ error: "서버 내부 오류", detail: error.message });
      }
    }
  `);

  newZip.file("vercel.json", `
    {
      "version": 2,
      "builds": [
        { "src": "package.json", "use": "@vercel/static-build" },
        { "src": "api/*.js", "use": "@vercel/node" }
      ],
      "routes": [
        { "src": "/api/(.*)", "dest": "/api/$1" },
        { "src": "/(.*)", "dest": "/index.html" }
      ]
    }
  `);

  newZip.file("package.json", `
    {
      "name": "realestate-info",
      "version": "1.0.0",
      "scripts": {
        "start": "react-scripts start",
        "build": "react-scripts build"
      },
      "dependencies": {
        "xml2js": "^0.6.2",
        "node-fetch": "^3.3.2"
      }
    }
  `);

  const buffer = await newZip.generateAsync({ type: "nodebuffer" });
  fs.writeFileSync("C:/realestate/realestate-vercel.zip", buffer);
  console.log("✅ 변환 완료! realestate-vercel.zip 파일이 생성되었습니다.");
}

convertToVercel();
