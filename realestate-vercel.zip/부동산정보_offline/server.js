import express from "express";
import fetch from "node-fetch";
import cors from "cors";
import { parseStringPromise } from "xml2js";

const app = express();
app.use(cors());

const PORT = 4000;

// ✅ 서울시 + 국토부 인증키
const SEOUL_API_KEY = "6c65626a4163686136305644734c78"; // 서울시 주소조회용
const MOLIT_API_KEY = "6c712922ba179a63f752341c8e77729a92a493a01169e4c73de1d90c110b0d6c"; // 국토부 건축물대장용

// ✅ 주소 → 코드 → 건축물 정보
app.get("/api/building", async (req, res) => {
  try {
    const query = req.query.addr;
    if (!query) return res.status(400).json({ error: "주소가 필요합니다." });

    console.log(`📍 [주소 요청] ${query}`);

    // 🥇 1단계: 서울시 주소 → 법정동 코드 변환
    const addrUrl = `https://openapi.seoul.go.kr:8088/${SEOUL_API_KEY}/json/GeoInfoAddress/1/5/${encodeURIComponent(
      query
    )}`;
    const addrRes = await fetch(addrUrl);
    const addrData = await addrRes.json();

    const addr = addrData.GeoInfoAddress?.row?.[0];
    if (!addr) {
      console.log("❌ 주소 검색 실패");
      return res.status(404).json({ error: "주소를 찾을 수 없습니다." });
    }

    const sigCd = addr.SIG_CD || "11710";
    const bjdongCd = addr.BJDONG_CD || "10400";
    const bun = addr.BUN?.padStart(4, "0") || "0000";
    const ji = addr.JI || "";

    console.log(`📄 [코드확인] sigCd=${sigCd}, bjdongCd=${bjdongCd}, bun=${bun}, ji=${ji}`);

    // 🥈 2단계: 국토부 건축물대장 조회 (XML → JSON 변환)
    const bldUrl = `https://apis.data.go.kr/1613000/BldRgstService_v2/getBrTitleInfo?sigunguCd=${sigCd}&bjdongCd=${bjdongCd}&bun=${bun}&ji=${ji}&ServiceKey=${MOLIT_API_KEY}&_type=xml`;
    const bldRes = await fetch(bldUrl);
    const xmlText = await bldRes.text();

    // XML을 JSON으로 변환
    const xmlData = await parseStringPromise(xmlText);
    const item = xmlData?.response?.body?.[0]?.items?.[0]?.item?.[0];

    if (!item) {
      console.log("❌ 건축물 정보 없음");
      return res.status(404).json({ error: "건축물 정보를 찾을 수 없습니다." });
    }

    // ✅ 성공: 결과 변환
    const result = {
      address: `${addr.SIGUN_NM || ""} ${addr.BJDONG_NM || ""} ${addr.BUN || ""}`,
      usageApproval: item.useAprDay?.[0] || "?",
      structure: item.strctCdNm?.[0] || "?",
      usage: item.mainPurpsCdNm?.[0] || "?",
      floors: item.grndFlrCnt?.[0] || "?",
      parking: item.totPkngCnt?.[0] || "?",
    };

    console.log("✅ 데이터 전송 성공");
    res.json(result);
  } catch (err) {
    console.error("🚨 서버 오류:", err);
    res.status(500).json({ error: "서버 내부 오류 발생" });
  }
});

app.listen(PORT, () =>
  console.log(`🚀 Proxy server running at http://localhost:${PORT}`)
);
