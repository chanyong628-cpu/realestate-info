import React, { useState } from "react";

function App() {
  const [query, setQuery] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSearch = async () => {
    if (!query.trim()) {
      alert("주소를 입력하세요 (예: 송파구 가락동 193)");
      return;
    }

    setLoading(true);
    setError(null);
    setData(null);

    try {
      console.log("🔍 요청보냄:", query);
      const response = await fetch(
        `http://localhost:4000/api/building?addr=${encodeURIComponent(query)}`
      );
      const result = await response.json();

      if (result.error) {
        setError(result.error);
      } else {
        setData(result);
      }
    } catch (err) {
      console.error("❌ 요청 실패:", err);
      setError("데이터를 불러오지 못했습니다.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: "40px", fontFamily: "sans-serif" }}>
      <h1>🏢 부동산 정보 조회</h1>
      <input
        type="text"
        placeholder="예: 송파구 가락동 193"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{
          width: "300px",
          padding: "8px",
          marginRight: "8px",
          borderRadius: "6px",
          border: "1px solid #ccc",
        }}
      />
      <button
        onClick={handleSearch}
        style={{
          padding: "8px 16px",
          borderRadius: "6px",
          backgroundColor: "#007bff",
          color: "#fff",
          border: "none",
          cursor: "pointer",
        }}
      >
        조회하기
      </button>

      <div style={{ marginTop: "20px" }}>
        {loading && <p>⏳ 조회 중...</p>}
        {error && <p style={{ color: "red" }}>⚠️ {error}</p>}
        {data && (
          <div style={{ marginTop: "16px" }}>
            <h3>📄 조회 결과</h3>
            <p><strong>주소:</strong> {data.address}</p>
            <p><strong>사용승인일:</strong> {data.usageApproval}</p>
            <p><strong>구조:</strong> {data.structure}</p>
            <p><strong>주용도:</strong> {data.usage}</p>
            <p><strong>지상층수:</strong> {data.floors}</p>
            <p><strong>총 주차대수:</strong> {data.parking}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
